AI INSTRUCTIONS (Frontend Spec)
Product

Сайт-меню для кафе «Шаурма на мангале».
Фронтенд только на HTML/CSS/JS (ES Modules), минимум зависимостей (разрешены только Google Fonts).
Бэкенд уже будет: фронт дергает REST-эндпоинты.

Branding

Палитра (CSS-переменные, использовать строго):

--cl-primary: #7F152E; (основной бордовый)

--cl-accent-1: #D61800;

--cl-accent-2: #EDAE01;

--cl-accent-3: #E94F08;

Нейтральные: --cl-bg: #FAFAFA; --cl-surface: #FFFFFF; --cl-text: #1C1C1C; --cl-muted: #767676; --cl-border: #E6E6E6;

Стиль иконок/иллюстраций: монохром, простые inline-SVG или emoji.

Логотип: временная заглушка (прямоугольник 120×32 с текстом).

Typography

Шрифты (Google Fonts, с поддержкой кириллицы/кыргызского):

Заголовки: Rubik (wght 400/500/700)

Текст/UI: Inter (wght 400/500/600)

Fallback: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial

Подключить <link rel="preconnect"> и <link rel="preload"> для шрифтов.

Размеры: base 16px; H1 28–32, H2 22–24, H3 18–20, UI 14–16.

i18n

Языки: ru, ky, en.

На каждой странице — селектор языка (иконка 🌐 + выпадающее).

Тексты грузить из /i18n/{lang}.json (ru/ky/en).

Валюта: KGS, формат: 180 сом (пробел перед «сом», без копеек).

Все текстовые узлы в HTML помечать data-i18n="key".

Страницы

/index.html — Меню

Категории (стандартный набор: «Шаурма», «Горячее», «Салаты», «Напитки», «Десерты») — список слева/вверху, sticky на мобиле.

Поиск по названию (debounce 250ms).

Фильтры по тегам (чекбоксы: вегетарианское, острое, хит, в наличии).

Карточки блюд: фото (lazy), название, цена «XXX сом», теги, кнопка «В корзину» (если is_available=false — лейбл «Нет в наличии» и disabled).

Если URL имеет ?table=NN — игнорировать (на этом этапе не нужно).

/cart.html — Корзина и оформление

Корзина из localStorage. Линии позиций: название, qty ±, цена, удалить.

Поля покупателя: name(обяз.), phone(обяз.), note(необяз.).

Поле «Когда приготовить»: по умолчанию «как можно быстрее». Пользователь может выбрать слот сегодня или до 14 дней вперёд. Если выбрано будущее время, должно быть минимум +15 минут от текущего момента.

Кнопка «Оформить заказ» → вызов POST /api/create_order.php. После ответа фронт делает редирект на /status.html?order=ORDER_ID.

Регистрация: быстрая, минимальная в модальном окне перед оформлением заказа:

Поля: телефон (обяз.), имя (обяз.), код-подтверждение (6 цифр) — имитация: отправка на бэкенд, фронт валидирует формат.

Сохранить токен (если придёт) в localStorage.

/status.html — Статус заказа + просмотр чека

По order_id из query.

Отображать прогресс: pending → accepted → ready → completed → canceled → failed.

Каждые 10 сек — опрос GET /api/order_status.php?order=ID.

Кнопка «Скачать чек (PDF)» или «Посмотреть чек» → ссылка GET /api/receipt.php?order=ID.

/policy.html — заглушка с текстом политики/оферты (i18n).

/reserve.html — не использовать (брони нет пока), файл не создавать.

Поиск/Фильтрация

Поиск: по name (без регистрозависимости).

Фильтры: массив тегов (пересечение): показывать только позиции, где tags содержит все выбранные.

Переключатель «в наличии» — фильтрует is_available=true.

Данные меню (карточка)
{
  "id": number,
  "name": string,
  "description": string,
  "price": number,
  "image": string|null,
  "is_available": boolean,
  "tags": ["veg","spicy","hit"] // произвольные
}

Валидации

Имя: 2–60 символов, кириллица/латиница, пробелы/дефис ok.

Телефон: маска +996 (XXX) XX-XX-XX, но хранить/отправлять только цифры (пример: 996555123456).

«Когда приготовить»:

по умолчанию — ASAP;

если выбран будущий слот: сегодня/до 14 дней вперёд, не раньше чем через 15 минут;

интервал слотов — 15 минут (00, 15, 30, 45).

UI-паттерны

Toast-нотификации (успех/ошибка) в правом/верхнем углу, автозакрытие 3.5с.

Inline-ошибки под полями форм. Disabled-состояния для кнопок при сабмите.

Кнопки не меньше 44px высотой; зоны клика — минимум 44×44.

Микро-анимации: transition: 180ms ease.

Доступность

Фокус-стили видимые.

aria-label на иконках, навигации, кнопках «в корзину», «оформить».

Контраст ≥ 4.5:1 (текст/фон).

Семантика: header, main, nav, section, footer.

SEO/мета

На каждой странице: корректный <title>, <meta name="description">, OG-теги.

favicon.ico — заглушка.

noindex для /status.html (мета robots).

Перфоманс

Без библиотек (никаких jQuery, UI-kits).

Lazy-loading изображений (loading="lazy"), предпочтительно webp.

Минимизировать reflow, использовать CSS Grid/Flex.

Критические стили — в <head> (небольшой критический блок), всё остальное — один assets/css/*.css.

Безопасность фронта

Никаких секретов/ключей в JS.

Анти-дребезг на сабмите (disable + спиннер).

Очистка/экранирование пользовательского ввода при рендере.

Интеграция с API (контракты, заглушки допустимы)

GET /api/menu.php → [{...menu_item}]

POST /api/register.php → {ok:true, token:"..."} (быстрая регистрация)

POST /api/login.php → {ok:true, token:"..."}

POST /api/create_order.php (body: {items:[{id,qty,note?}], name, phone, when:{type:"asap"|"scheduled", datetime?}})
→ {ok:true, order_id:123}

GET /api/order_status.php?order=ID → {status:"pending"|"accepted"|"ready"|"completed"|"canceled"|"failed", receipt_url?:string}

GET /api/receipt.php?order=ID → PDF/HTML (открывать в новой вкладке)

Ошибки API всегда в формате {ok:false, error:"CODE", message:"..."} — показывать toast + inline где возможно.

Файловая структура (строго)
/                           (корень сайта)
├─ index.html               // Меню, поиск, категории, фильтры
├─ cart.html                // Корзина + регистрация (модал) + оформление + "Когда приготовить"
├─ status.html              // Трекинг статуса заказа + ссылка на чек
├─ policy.html              // Политика/оферта (i18n текст)
│
├─ /assets
│  ├─ /css
│  │  ├─ tokens.css        // Переменные: цвета, шрифты, радиусы, тени, z-index, брейки
│  │  ├─ base.css          // Reset/normalize (короткий), типографика, ссылки, формы
│  │  ├─ layout.css        // Контейнеры, сетки, header/nav/footer, responsive
│  │  ├─ components.css    // Кнопки, инпуты, карточки, тосты, модалки, лоадеры
│  │  └─ pages.css         // Локальные доработки страниц (минимум)
│  ├─ /img                 // Изображения блюд (webp/jpg), заглушки
│  └─ /icons               // Инлайн SVG (монохром)
│
├─ /i18n
│  ├─ ru.json              // Ключи/значения интерфейса (см. ниже)
│  ├─ ky.json
│  └─ en.json
│
└─ /js
   ├─ app.js               // Общая инициализация: язык, шрифты, тосты, делегирование
   ├─ api.js               // fetch-утилиты к API (см. ниже)
   ├─ auth.js              // быстрая регистрация/логин (модалка, хранение токена)
   ├─ cart.js              // корзина (localStorage), расчёт total, qty ±, валидация
   ├─ ui.js                // тосты, модалки, спиннеры, helpers, formatPrice
   ├─ i18n.js              // загрузка json, подстановка по data-i18n
   ├─ menu.js              // логика index.html: рендер списка, фильтры, поиск
   ├─ checkout.js          // логика cart.html: формы, маска телефона, "Когда приготовить"
   └─ status.js            // логика status.html: polling статуса, показ чека

Пояснения по файлам

tokens.css: объявить :root{} переменные (цвета, типографика, spacing 4/8/12/16, радиусы 6/10/14, тени, брейки --bp-sm:480px; --bp-md:768px; --bp-lg:1024px).

base.css: короткий reset + базовая типографика, ссылки, фокус-стили.

layout.css: .container {max-width: 1100px; margin:0 auto; padding:0 16px}; шапка с логотипом, селектор языка.

components.css: .btn, .btn--primary, .input, .badge, .card, .toast, .modal, .skeleton.

pages.css: только тонкие правки (например, сетка карточек меню на index.html).

app.js:

читает/ставит текущий язык, инициирует i18n, вешает обработчик на селектор языка;

экспортирует bus (простое событие/подписка) или использует кастомные события DOM;

инициализирует тост-контейнер.

api.js (контракты строго):

export async function getMenu(){ ... }            // GET /api/menu.php
export async function registerFast(data){ ... }   // POST /api/register.php
export async function loginFast(data){ ... }      // POST /api/login.php
export async function createOrder(data){ ... }    // POST /api/create_order.php
export async function getOrderStatus(id){ ... }   // GET /api/order_status.php?order=id
export function openReceipt(id){ window.open(`/api/receipt.php?order=${id}`, '_blank'); }


auth.js: модалка «быстрая регистрация» (телефон, имя, код). Сохраняет token в localStorage (ordify_token).

cart.js: хранит корзину в localStorage (ordify_cart). Экспортирует:
getCart(), setCart(items), add(item, qty), remove(id), updateQty(id, qty), clear(), getTotal().

i18n.js: грузит /i18n/{lang}.json, заменяет [data-i18n] на значения, хранит язык в localStorage (ordify_lang).

menu.js:

грузит список с getMenu();

применяет фильтры/поиск;

рендерит карточки;

обработчик «В корзину».

checkout.js:

читает корзину;

валидирует поля (имя, телефон);

рендерит контрол «Когда приготовить»:

переключатель ASAP / Запланировать;

если «Запланировать» — дата сегодня..+14 дней, время шагом 15 мин;

не раньше текущего времени +15 мин;

сабмит → createOrder() → редирект на /status.html?order=....

status.js:

читает order_id из query;

раз в 10 сек опрашивает getOrderStatus();

рисует прогресс-бар/чипы статуса;

кнопка «Скачать/Посмотреть чек» → openReceipt(order_id).

i18n JSON (пример ключей)

/i18n/ru.json

{
  "app.title": "Шаурма на мангале",
  "nav.menu": "Меню",
  "nav.cart": "Корзина",
  "menu.search.placeholder": "Поиск по названию",
  "menu.filter.available": "В наличии",
  "menu.tags.veg": "Вегетарианское",
  "menu.tags.spicy": "Острое",
  "menu.tags.hit": "Хит",
  "item.add": "В корзину",
  "cart.title": "Оформление заказа",
  "cart.name": "Имя",
  "cart.phone": "Телефон",
  "cart.note": "Комментарий",
  "cart.when": "Когда приготовить",
  "cart.when.asap": "Как можно быстрее",
  "cart.when.schedule": "Запланировать",
  "cart.submit": "Оформить заказ",
  "status.title": "Статус заказа",
  "status.viewReceipt": "Посмотреть чек",
  "toast.added": "Добавлено в корзину",
  "error.required": "Обязательное поле",
  "error.phone": "Неверный формат телефона"
}


(Аналогично ky.json, en.json — ключи те же.)

Код-стайл (строго)

Только ES Modules (type="module") и import/export.

Одна ответственность на модуль; без глобальных переменных (кроме window.ordifyVersion).

Имена классов в CSS — BEM (.card, .card__title, .btn--primary).

Никаких !important.

Комментарии JSDoc у публичных функций.

Все fetch — c try/catch, обработка ошибок и тост.

Никаких сторонних JS-библотек, кроме fetch (встроенный).

Тестовые данные (для заглушек)

Если GET /api/menu.php недоступен — рендерить 6 карточек-заглушек (skeleton) и показать тост «Нет соединения».

В карточках без image — ставить заглушку-серый прямоугольник 4:3.

Что ДОЛЖНО быть строго (от структуры до кода)

Файловая структура и имена файлов — как выше.

Подключение CSS в порядке: tokens.css, base.css, layout.css, components.css, pages.css.

Подключение JS: app.js + страничный модуль (menu.js/checkout.js/status.js).

Все тексты — через i18n; никаких хардкодов в HTML, кроме атрибутов data-i18n.

Формат цены — formatPrice(число) => "123 сом".

Маска телефона — нативная через input-события, без библиотек.

ASAP/Запланировать — логика с 15-минутным минимумом и окном +14 дней.

Статус заказа — опрос каждые 10 сек, без WebSocket.

Кнопка «Чек» на /status.html — всегда видна, если receipt_url пришла.

Что можно варьировать дизайнерски

Радиусы (но в пределах токенов), тени, hover-анимации, скругления карточек, вид бейджей.

Порядок элементов внутри карточки (если соблюдена семантика и доступность).

Сетка карточек: 2 колонки на мобиле ≥360px, 3 — ≥768px, 4 — ≥1024px.
